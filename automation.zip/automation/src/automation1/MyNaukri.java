package automation1;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MyNaukri {

	public static void main(String[] args) {
		
		WebDriver d = new ChromeDriver();
				
		d.get("https://www.google.com/");
		
		d.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input")).sendKeys("Naukri.com");
		d.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input")).sendKeys(Keys.ENTER);
		
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		
		d.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div[1]/a/h3")).click();
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		d.findElement(By.linkText("LOGIN")).click();
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		d.findElement(By.xpath("//*[@id=\"eLoginNew\"]")).sendKeys("rahulthakral1996@gmail.com");
		d.findElement(By.xpath("//*[@id=\"pLogin\"]")).sendKeys("2806@1996");
		d.findElement(By.xpath("//*[@id=\"lgnFrmNew\"]/div[9]/button")).click();
		d.manage().window().maximize();
		
		Set<String> wins=	d.getWindowHandles();  //return list of windows
		System.out.println(wins.size());
		for(String win : wins ) //: iterator 
		{
		  	d.switchTo().window(win);
		  	String title  = d.getTitle();
		  	System.out.println(title);
		  	
		  	
		/* if(title.startsWith(("Prokarma")||("ICON Clinical Research")))
		 {	
			 d.close();
		 }*/
		}
		
	    WebElement el = d.findElement(By.xpath("/html/body/div[1]/div/div/ul[2]/li[2]/a/div[2]"));

		
	    Actions act =new Actions(d);
	    act.moveToElement(el).build().perform();
	    
	    d.findElement(By.linkText("Recommended Jobs")).click();
	    d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	    //d.findElement(By.xpath("/html/body/div[2]/div/ul[2]/li[2]/div/ul[1]/li[2]/a")).click();
	    d.findElement(By.cssSelector("#root > div > div > span > div > div > div > div > div.wrapper > div > div.row > div.col.s4.pr0 > div:nth-child(1) > div > div")).click();
	
		
				
		//d.findElement(By.xpath("//*[@id=\"skill\"]/div[1]/div[2]/input")).sendKeys("Software Testing");
		//d.findElement(By.xpath("//*[@id=\"skill\"]/div[1]/div[2]/input")).sendKeys(Keys.TAB);
		//d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		//d.findElement(By.xpath("//*[@id=\"location\"]/div[1]/div[2]/input")).sendKeys("Delhi");
		//d.findElement(By.xpath("//*[@id=\"location\"]/div[1]/div[2]/input")).sendKeys(Keys.TAB);
	
	}
	
}

	
	
	
	
	