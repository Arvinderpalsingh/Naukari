package automation1;

import java.io.FileInputStream;

public class AmazonFlipkart {

	FileInputStream fs = new FileInputStream("C:\\Users\\DELL LAPTOP\\Desktop\\SOFTWARE TESTING MATERIAL");
	HSSFWorkbook book = new HSSFWorkbook(fs);
	HSSFSheet sheet = book.getSheet("Sheet1");
	
	int wsc,rc,cc;		
	wsc = book.getNumberOfSheets();
	rc = sheet.getPhysicalNumberOfRows();
	
	cc = sheet.getRow(0).getPhysicalNumberOfCells();
	
	System.out.println("sheet count :"+wsc);
	System.out.println("row count :"+rc);
	System.out.println("col count :"+cc);
	
	for(int i=1;i<rc;i++)
	{
		HSSFRow row = sheet.getRow(i);
		
		HSSFCell cell =row.getCell(1);
		System.out.println(cell.getStringCellValue());
		
		//driver.get("flip...")
		//driver.findElement(By.id("id")).sendKeys(cell.getStringCellValue())
		
		//driver.get("amazon..")
		//driver.findElement(By.id("id")).sendKeys(cell.getStringCellValue())
		
		cell =row.getCell(2);
		System.out.println(cell.getDateCellValue());
		
		
		
	}
	
	
}



}