package automation1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class gmail {

	public static void main(String[] args) {
		WebDriver d = new ChromeDriver();
	
		d.get("http://www.google.com/");
	
		//d.findElement(By.linkText("Gmail"));
		d.findElement(By.linkText("Gmail")).sendKeys(Keys.ENTER);
		
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		
		d.findElement(By.linkText("SIGN IN"));
		d.findElement(By.linkText("SIGN IN")).click();
		
		d.findElement(By.id("identifierId")).sendKeys("rahulthakral1996");
		d.findElement(By.id("identifierId")).sendKeys(Keys.ENTER);
		
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		d.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys("2806@1996");
		d.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys(Keys.ENTER);
		
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		d.findElement(By.linkText("LOGIN")).sendKeys(Keys.ENTER);
		d.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);

	}

}
