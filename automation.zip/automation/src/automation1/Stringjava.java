package automation1;

public class Stringjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 
		//array : collection of multiple values
				String words[]= {"selenium","java","movies"};
				
				for(String w: words)  //read every string from array one by one
				{
					System.out.println(w);
				}

			}

			}
