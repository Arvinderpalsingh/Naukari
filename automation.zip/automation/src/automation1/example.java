package automation1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class example {

	public static void main(String[] args) {
	WebDriver d = new ChromeDriver();
	d.get("http://www.google.com/");
	
	String url, title;
	title = d.getTitle();
	url = d.getCurrentUrl();
	System.out.println("Page Title is : "+title);
	System.out.println("Page url is : "+url);

	//event
	d.findElement(By.id("lst-ib")).sendKeys("Gmail");
	d.findElement(By.id("lst-ib")).sendKeys(Keys.ENTER);
	
	}

}
