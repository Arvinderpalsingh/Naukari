package automation1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Amazonclass {

	public static void main(String[] args) Throws Exception{
  FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\Desktop\\Rohit Sessions - Sep 3rd\\Sample - Superstore.xls");
HSSFWorkbook book = new HSSFWorkbook(fs);
HSSFSheet sheet = book.getSheet("Sheet4");
	}

}
